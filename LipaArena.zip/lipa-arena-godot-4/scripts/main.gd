extends Node3D

func _ready() -> void:
    _create_arena()
    _create_player()
    _create_camera()
    _create_light()
    _create_hud()

func _create_arena() -> void:
    var floor := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(30, 30)
    floor.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.22, 0.19)
    floor.material_override = mat
    add_child(floor)

    for x in range(-12, 13, 3):
        for z in range(-12, 13, 3):
            var marker := MeshInstance3D.new()
            var box := BoxMesh.new()
            box.size = Vector3(0.035, 0.01, 0.035)
            marker.mesh = box
            marker.position = Vector3(x, 0.012, z)
            var marker_mat := StandardMaterial3D.new()
            marker_mat.albedo_color = Color(0.25, 0.38, 0.32)
            marker.material_override = marker_mat
            add_child(marker)

func _create_player() -> void:
    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.5
    body.mesh = capsule
    body.position = Vector3(0, 0.78, 0)
    var body_mat := StandardMaterial3D.new()
    body_mat.albedo_color = Color(0.12, 0.35, 0.85)
    body.material_override = body_mat
    add_child(body)

    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.3
    sphere.height = 0.6
    head.mesh = sphere
    head.position = Vector3(0, 1.65, 0)
    var head_mat := StandardMaterial3D.new()
    head_mat.albedo_color = Color(0.95, 0.68, 0.32)
    head.material_override = head_mat
    add_child(head)

func _create_camera() -> void:
    var camera := Camera3D.new()
    camera.position = Vector3(0, 13, 13)
    camera.rotation_degrees = Vector3(-42, 0, 0)
    camera.current = true
    add_child(camera)

func _create_light() -> void:
    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55, -25, 0)
    light.light_energy = 1.2
    add_child(light)

func _create_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var title := Label.new()
    title.text = "LIPA ARENA  |  TRAINING ARENA"
    title.position = Vector2(24, 18)
    title.add_theme_font_size_override("font_size", 24)
    layer.add_child(title)

    var hint := Label.new()
    hint.text = "Первый прототип: Кайрон. Управление и способности добавим следующим шагом."
    hint.position = Vector2(24, 54)
    hint.add_theme_font_size_override("font_size", 16)
    layer.add_child(hint)
