extends Control
## Временная заготовка сенсорного джойстика для будущего мобильного управления.
var output := Vector2.ZERO
var touch_index := -1

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and touch_index == -1:
            touch_index = event.index
            _update_output(event.position)
        elif not event.pressed and event.index == touch_index:
            touch_index = -1
            output = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == touch_index:
        _update_output(event.position)

func _update_output(local_position: Vector2) -> void:
    var center := size * 0.5
    output = (local_position - center).limit_length(1.0)
