extends CharacterBody3D
## Заготовка для будущего игрового персонажа Кайрона.
@export var move_speed: float = 5.0

func _physics_process(_delta: float) -> void:
    var input_dir := Vector2(
        Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left"),
        Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    )
    var direction := Vector3(input_dir.x, 0.0, input_dir.y).normalized()
    velocity.x = direction.x * move_speed
    velocity.z = direction.z * move_speed
    move_and_slide()
